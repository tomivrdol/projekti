import React from 'react';
import '../css/CurrentDetail-info.css';

const CurrentDetailInfo = ({description,kelvinToCelsius}) => {

    const tempMax = kelvinToCelsius(description.main.temp_max); 
    const tempLow = kelvinToCelsius(description.main.temp_min); 
    const wind = Math.round(description.wind.speed); 
    const feelsLike = kelvinToCelsius(description.main.feels_like);
    const pressure = description.main.pressure;
    const humidity = description.main.humidity;
    
    return(
        <div className="info-right">
                        <div className="info-piece">
                            <div className="a">
                                <p>{tempMax}</p>
                                <p className="dark-white">High</p>
                            </div>
                        </div>
                        <div className="info-piece">
                            <div className="a">
                                <p>{feelsLike}</p>
                                <p className="dark-white">Feels</p>
                            </div>
                        </div>
                        <div className="info-piece">
                            <div className="a">
                                <p>{wind} mph</p>
                                <p className="dark-white">Wind</p>
                            </div>
                        </div>
                        <div className="info-piece">
                            <div className="a">
                                <p>{tempLow}</p>
                                <p className="dark-white">Low</p>
                            </div>
                        </div>
                        <div className="info-piece">
                            <div className="a">
                                <p>{pressure}</p>
                                <p className="dark-white">Pressure</p>
                            </div>
                        </div>
                        <div className="info-piece">
                            <div className="a">
                                <p>{humidity} %</p>
                                <p className="dark-white">Humidity</p>
                            </div>
                        </div>
                    </div>
    );
}

export default CurrentDetailInfo;