import React from 'react';
import moment from 'moment';
import '../css/CurrentDetails.css';
import CurrentDetailInfo from './CurrentDetail-info';


const CurrentDetails = ({weatherDetails,kelvinToCelsius}) => {

    if(!weatherDetails){
        return <div>Loading...</div>;
    }


    const city = weatherDetails.data.city.name;
    const country = weatherDetails.data.city.country;
    const date = weatherDetails.data.list[0].dt_txt;
    const temp = kelvinToCelsius(weatherDetails.data.list[0].main.temp);
    const weatherDescription = weatherDetails.data.list[0].weather[0].description;
    const icon = weatherDetails.data.list[0].weather[0].icon;
    const iconSrc = `http://openweathermap.org/img/wn/${icon}@2x.png`;
 
    
    const dateFormated = moment(date).format('MMMM Do dddd');

    

    
    return(
        <div className="currently-details">
                <div className="city-heading">
                    <h3>{city}, {country}</h3>
                    <p>{dateFormated}</p>
                </div>
                <div className="info">
                    <div className="info-left">
                        <div className="icon">
                            <img src={iconSrc} alt = "icon"/>
                        </div>
                        <div className="temp">
                            <h1>{temp} C</h1>
                            <p>{weatherDescription}</p>
                        </div>
                    </div>

                    <div className="vertical-line"></div>
                    
                    <CurrentDetailInfo description = {weatherDetails.data.list[0]} kelvinToCelsius = {kelvinToCelsius}/>
                    
                </div>
            </div>
    );
}

export default CurrentDetails;