import React from 'react';
import moment from 'moment';
import '../css/TodayDetails-hour.css';

const TodayDetailsHour = ({hour,temp,icon,kelvinToCelsius}) => {
   

    const tempFormated = kelvinToCelsius(temp);
    const hourFormated = moment(hour).format('LT');
    const iconSrc = `http://openweathermap.org/img/wn/${icon}@2x.png`;

    
    return(
        <div className="hour">
            <p>{hourFormated}</p>
            <img src={iconSrc} alt = "icon"/>
            <p>{tempFormated} C</p>
        </div>
    );
}

export default TodayDetailsHour;