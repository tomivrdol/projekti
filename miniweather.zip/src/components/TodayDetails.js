import React from 'react';
import '../css/TodayDetails.css';
import TodayDetailsHour from './TodayDetails-hour';


const TodayDetails = ({weatherDetails,kelvinToCelsius}) => {

   

    if(!weatherDetails){
        return <div>Loading...</div>;
    }else{
        
    }
    const a = weatherDetails.data.list.slice(1,8);
  

    const renderedList = a.map((detail) => {
        return <TodayDetailsHour hour = {detail.dt_txt} temp = {detail.main.temp} icon = {detail.weather[0].icon} kelvinToCelsius = {kelvinToCelsius}/>
    })

    return(
        <div className="today-details">
                <div className="today-heading">
                    <h3>Next 24 hours</h3>
                </div>
                <div className="today-hour">
                    {renderedList}
                </div>
           </div>
    );
}

export default TodayDetails;