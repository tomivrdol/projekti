import React from 'react';
import axios from 'axios';
import '../css/SearchBar.css';

class SearchBar extends React.Component{
    state = {term: []};

    onInputChange = (event) => {
        this.setState({term: event.target.value});
    }

    onFormSubmit = (event) => {
        event.preventDefault();
        this.props.makeRequest(this.state.term);
    }

    render(){
        return(
            <div className="search-bar">
                    <form onSubmit={this.onFormSubmit}>
                        <input 
                            type="text" 
                            placeholder="Search Weather.." 
                            name="search"
                            onChange={this.onInputChange}
                            value={this.state.term}
                        />
                    </form>
            </div>
        );
    }
}

export default SearchBar;