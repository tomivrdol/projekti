import React from 'react';
import '../css/FutureDetails-day.css';
import moment from 'moment';

const FutureDetailsDay = ({weatherForEachDay,kelvinToCelsius}) => {


    const date = moment(weatherForEachDay.dt_txt).format("MMM Do YY");
    const day = moment(weatherForEachDay.dt_txt).format('dddd');

    const dayFormated = day.slice(0,3);

    const icon = weatherForEachDay.weather[0].icon;
    const iconSrc = `http://openweathermap.org/img/wn/${icon}@2x.png`;

    const temp = kelvinToCelsius(weatherForEachDay.main.temp);
    const high = kelvinToCelsius(weatherForEachDay.main.temp_max);
    const low = kelvinToCelsius(weatherForEachDay.main.temp_min);
    const wind = kelvinToCelsius(weatherForEachDay.wind.speed);

    console.log(date);

    return(
        <div class="day">
            <div class="fut aa">
                    <p>{dayFormated}</p>
                    <p class="dark-white">{date}</p>
            </div>
            <div class="fut aa">
                <img src={iconSrc} alt="img"/>
            </div>
            <div class="fut aa">
                <p>{temp} C</p>
                <p class="dark-white">Temp</p>
            </div>
            <div class="fut aa">
                <p>{high} C</p>
                <p class="dark-white">High</p>
            </div>
            <div class="fut aa">
                <p>{low}</p>
                <p class="dark-white">Low</p>
            </div>
            <div class="fut aa">
                <p>{wind}</p>
                <p class="dark-white">Wind</p>
            </div>
        </div>
    );

}

export default FutureDetailsDay;