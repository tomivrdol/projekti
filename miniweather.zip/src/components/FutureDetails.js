import React from 'react';
import '../css/FutureDetails.css';
import FutureDetailsDay from './FutureDetails-day';

const FutureDetails = ({weatherDetails, kelvinToCelsius}) => {

    if(!weatherDetails){
        return <div>Loading...</div>;
    }


    const weatherForEachDay = [];
    weatherForEachDay.push(weatherDetails.data.list[8]);
    weatherForEachDay.push(weatherDetails.data.list[16]);
    weatherForEachDay.push(weatherDetails.data.list[24]);
    weatherForEachDay.push(weatherDetails.data.list[32]);
    weatherForEachDay.push(weatherDetails.data.list[39]);

    console.log(weatherForEachDay);

    const renderedList = weatherForEachDay.map((day) => {
        return <FutureDetailsDay weatherForEachDay={day} kelvinToCelsius = {kelvinToCelsius}/>;
    });

    return(
        <div class="future-details">
            <div class="future-heading">
                <p>Next 5 days</p>
            </div>
            <div class="future-day">
                {renderedList}
            </div>
           </div>
    );
}

export default FutureDetails;