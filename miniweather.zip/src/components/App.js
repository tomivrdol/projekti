import React from 'react';
import CurrentDetails from './CurrentDetails';
import TodayDetails from './TodayDetails';
import FutureDetails from './FutureDetails';
import SearchBar from './SearchBar';
import '../css/App.css';
import axios from 'axios';


class App extends React.Component{
    state = {weather: null, dayOrNight: ''};
    

     makeRequest = async (param) => {
        const response = await axios.get('https://api.openweathermap.org/data/2.5/forecast',{
            params: {
                q: param,
                appid: '7b1245c066db90cd649814b600da1660'
            }
        })
        
        this.setState({weather: response});
        this.setState({dayOrNight: this.state.weather.data.list[0].weather[0].icon.substr(-1)});
 
    }

    componentDidMount(){
        this.makeRequest('Split');
    }

    kelvinToCelsius(kelvin){
        return Math.round(kelvin - 273.15);
    }


    render(){
        
        return(
            <div className={`main ${this.state.dayOrNight}`}>
                <div className='container'>
                    <SearchBar makeRequest = {this.makeRequest}/>
                    <CurrentDetails weatherDetails = {this.state.weather} kelvinToCelsius = {this.kelvinToCelsius}/>
                    <TodayDetails weatherDetails = {this.state.weather} kelvinToCelsius = {this.kelvinToCelsius}/>
                    <FutureDetails weatherDetails = {this.state.weather} kelvinToCelsius = {this.kelvinToCelsius}/>
                </div>
            </div>
        );
    }
}

export default App;